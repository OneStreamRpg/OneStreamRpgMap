<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="autumn trees (leaves) 80x112" tilewidth="80" tileheight="112" tilecount="3" columns="3">
 <image source="../autumn sheets/autumn trees (leaves) 80x112.png" width="240" height="112"/>
</tileset>
