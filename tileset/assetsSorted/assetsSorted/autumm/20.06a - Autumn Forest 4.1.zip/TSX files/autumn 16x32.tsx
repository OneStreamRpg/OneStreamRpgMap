<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="autumn 16x32" tilewidth="16" tileheight="32" tilecount="6" columns="6">
 <image source="../autumn sheets/autumn 16x32.png" width="96" height="32"/>
</tileset>
