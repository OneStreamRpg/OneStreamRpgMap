<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="autumn forest, tree wall (bare canopy only)" tilewidth="128" tileheight="128" tilecount="24" columns="6">
 <image source="../autumn tree wall/autumn forest, tree wall (bare canopy only).png" width="768" height="512"/>
</tileset>
