Thank you for purchasing one of Mana Seed game assets!

If you want some more, you can find the full collection on itch.io:
https://seliel-the-shaper.itch.io/

Make sure you understand your rights and restrictions by reading the Mana Seed User License:
https://selieltheshaper.weebly.com/user-license.html

Get support and feedback from the community by joining the Mana Seed Discord Server!
https://selieltheshaper.weebly.com/discord.html

Finance the creation of new Mana Seed assets by ordering a commission:
https://selieltheshaper.weebly.com/commissions.html

If you want to support me more directly, please visit my Patreon or Ko-fi!
https://www.patreon.com/selieltheshaper
https://ko-fi.com/selieltheshaper