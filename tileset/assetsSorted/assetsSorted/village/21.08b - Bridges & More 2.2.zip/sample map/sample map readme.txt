How to access the sample map:

Step 1) Download Tiled (for free) here:
https://thorbjorn.itch.io/tiled

Step 2) Install Tiled.

Step 3) Make sure the sample map TMX/TSX files in the same folder as the tileset PNGs.

Step 4) Open the sample map! This is the TMX file. The TSX files are for the tileset in use, not the map.


This is only meant to be a helpful usage guide, and you are free to use the tileset any way you see fit.

Thanks!
Seliel