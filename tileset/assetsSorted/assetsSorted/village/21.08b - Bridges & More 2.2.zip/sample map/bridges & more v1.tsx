<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="bridges &amp; more" tilewidth="16" tileheight="16" tilecount="48" columns="16">
 <image source="bridges &amp; more v1.png" width="256" height="48"/>
</tileset>
