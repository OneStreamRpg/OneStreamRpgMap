<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="evergreen trees, tree wall (winter, full &amp; top snow, canopy only) 128x128" tilewidth="128" tileheight="128" tilecount="24" columns="6">
 <image source="../evergreen trees, tree wall (winter, full &amp; top snow, canopy only) 128x128.png" width="768" height="512"/>
 <wangsets>
  <wangset name="Unnamed Set" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="1" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="3" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="4" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="5" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="9" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="11" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="12" wangid="0,1,0,0,0,1,0,0"/>
   <wangtile tileid="13" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="14" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="15" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="16" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="17" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="18" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="19" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="20" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
