<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="evergreen trees (spring) 80x112" tilewidth="80" tileheight="112" tilecount="28" columns="7">
 <image source="../Tilesets/evergreen trees (spring) 80x112.png" width="560" height="448"/>
</tileset>
