<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="bonus bridge" tilewidth="64" tileheight="48" tilecount="1" columns="1">
 <image source="../extras/bonus bridge.png" width="64" height="48"/>
</tileset>
