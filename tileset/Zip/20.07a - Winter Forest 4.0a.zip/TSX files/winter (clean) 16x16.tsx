<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="winter (clean) 16x16" tilewidth="16" tileheight="16" tilecount="30" columns="6">
 <image source="../_winter sheets/winter (clean) 16x16.png" width="96" height="80"/>
</tileset>
