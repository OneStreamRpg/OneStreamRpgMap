<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="winter (leaves) 48x32" tilewidth="48" tileheight="32" tilecount="3" columns="3">
 <image source="../_winter sheets/winter (leaves) 48x32.png" width="144" height="32"/>
</tileset>
