<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="winter (snowy) 32x32" tilewidth="32" tileheight="32" tilecount="7" columns="7">
 <image source="../winter sheets/winter (snowy) 32x32.png" width="224" height="32"/>
</tileset>
